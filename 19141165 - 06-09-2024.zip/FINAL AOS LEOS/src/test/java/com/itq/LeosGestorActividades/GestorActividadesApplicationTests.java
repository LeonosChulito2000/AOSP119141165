package com.itq.LeosGestorActividades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorActividadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
