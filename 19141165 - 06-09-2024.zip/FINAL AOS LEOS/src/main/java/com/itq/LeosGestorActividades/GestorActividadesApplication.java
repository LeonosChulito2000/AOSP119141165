package com.itq.LeosGestorActividades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestorActividadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestorActividadesApplication.class, args);
	}

}
